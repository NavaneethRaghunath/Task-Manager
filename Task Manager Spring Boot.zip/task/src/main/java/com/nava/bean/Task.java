package com.nava.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;


@Component
@Entity  
public class Task {  
	
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int taskid;  
    
    private int parentid;
    private String task;  
    private String startdate;  
    private String enddate;
    private int priority;
    
	public int getTaskid() {
		return taskid;
	}
	public void setTaskid(int taskid) {
		this.taskid = taskid;
	}
	
	
	public int getParentid() {
		return parentid;
	}
	public void setParentid(int parentid) {
		this.parentid = parentid;
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	
	@Override
	public String toString() {
		return "Task [taskid=" + taskid + ", parentid=" + parentid + ", task=" + task + ", startdate=" + startdate
				+ ", enddate=" + enddate + ", priority=" + priority + "]";
	}
    
    
}
