package com.nava.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nava.bean.Parent;
import com.nava.bean.Task;
import com.nava.model.Modeltask;
import com.nava.model.Mytask;
import com.nava.service.task.TaskServiceImpl;

@RestController  
@CrossOrigin(origins = "*")

@RequestMapping(value={"/mytask"}) 
public class TaskController {  
      
	@Autowired
    TaskServiceImpl taskservice;
	
	@Autowired
	Parent parent;
	
	@Autowired
	Task mytask;
	
 	
	@PostMapping(value = "/add-task",headers="Accept=application/json", produces = {"application/json"})  
    public ResponseEntity<Mytask> saveTask(@RequestBody Mytask task) {  
    		
    		parent.setParentid(0);
    		parent.setParenttask(task.getParenttask());
 
    		taskservice.saveParentTask(parent);
    		
    		int parentId = taskservice.findpid(task.getParenttask());
    		   
    		mytask.setTaskid(0);
    		mytask.setParentid(parentId);
    		mytask.setTask(task.getTask());    		
    		mytask.setStartdate(task.getStartdate());
    		mytask.setEnddate(task.getEnddate());
    		mytask.setPriority(task.getPriority());

    		taskservice.saveTask(mytask);
    		
    		return new ResponseEntity<Mytask>(task,HttpStatus.OK);
    
    }
      
   
	@GetMapping(value = "/gettask", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Mytask> alltasks() {  
    	
          return taskservice.getTasks();  
    
    } 
    
      
	@PutMapping(value ="/updatetask", headers="Accept=application/json", produces = MediaType.APPLICATION_JSON_VALUE)  
    public ResponseEntity<Modeltask> updateTask(@RequestBody Modeltask task) {  
        
		taskservice.updateTask(task.getTaskid(),task.getTask(),task.getStartdate(),task.getEnddate(),task.getPriority());
		
		taskservice.updateParentTask(task.getTaskid(),task.getParenttask());
		return new ResponseEntity<Modeltask>(task, HttpStatus.OK);

	}  
    
    @PutMapping(value="/update-date", headers="Accept=application/json", produces = MediaType.APPLICATION_JSON_VALUE)  
    public ResponseEntity<Mytask> updateEnddate(@RequestBody Mytask task) {  
		
    	taskservice.updateEnddate(task.getTaskid(),task.getEnddate());  

    	return new ResponseEntity<Mytask>(task, HttpStatus.OK);

    }     
    
    @DeleteMapping(value = "/delete-task/{id}")
    public void deleteTask(@PathVariable int id) {

        taskservice.delete(id);

    }    
    
}  
