import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { TaskserviceService } from '../taskservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {

  addTaskForm: FormGroup;

  constructor(private taskservice: TaskserviceService,
              private router: Router) { }

  ngOnInit() {
    this.addTaskForm = new FormGroup({
      task: new FormControl(),
      priority: new FormControl(),
      parenttask: new FormControl(),
      startdate: new FormControl(),
      enddate: new FormControl()
    });    
  }

  addtask() :void{

    this.taskservice.createTask(this.addTaskForm.value).subscribe(data =>{
            alert("task added!");
            this.router.navigate(['/view-task']);
           },
      error =>{alert(error);
     })

  }

}
