import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewTaskComponent } from './view-task/view-task.component';
import { AddTaskComponent } from './add-task/add-task.component';
import { UpdateTaskComponent } from './update-task/update-task.component';

const routes: Routes = [  
  { path: '', redirectTo: 'view-task', pathMatch: 'full' },  
  { path: 'view-task', component: ViewTaskComponent },  
  { path: 'add-task', component: AddTaskComponent },  
  { path: 'update-task', component: UpdateTaskComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
