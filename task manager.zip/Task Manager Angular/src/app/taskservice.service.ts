import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';  
import { Observable } from 'rxjs';  
import { Modeltask } from './Modeltask';
import { DatePipe } from '@angular/common';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class TaskserviceService {

  private baseUrl = 'http://localhost:8080/mytask/';  

  currentDate: Date;

  constructor(private http:HttpClient,
              private datePipe: DatePipe) { }

  createTask(task: Modeltask): Observable<any> {
    task.startdate = this.datePipe.transform(task.startdate, 'dd/MM/yyyy');
    task.enddate = this.datePipe.transform(task.enddate, 'dd/MM/yyyy');
    console.log(task);
    return this.http.post(`${this.baseUrl}`+'add-task', task, httpOptions);  
  }

  // getmytask() {
  //   return [
  //     {taskid: 1, task: 'Hydrogen', parenttask: 'Nitrogen', startdate: '12/1/2109', enddate: '12/1/2009', priority: 2},
  //     {taskid: 2, task: 'nava', parenttask: 'oxy', startdate: '12/1/21', enddate: '12/1/20', priority: 2}
  //   ];
 
  // }

  getTask(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'gettask');  
  }
  
  updateTask(task: Modeltask): Observable<any>{
    // task.startdate = this.datePipe.transform(task.startdate, 'dd/MM/yyyy');
    // task.enddate = this.datePipe.transform(task.enddate, 'dd/MM/yyyy');
    return this.http.put(`${this.baseUrl}`+'updatetask', task, httpOptions);  
  }

  putTaskDate(task: any): Observable<any>{
    this.currentDate = new Date();
    task.enddate = this.datePipe.transform(this.currentDate, 'dd/MM/yyyy');
    console.log(task);
    return this.http.put(`${this.baseUrl}`+'update-date', task, httpOptions);  
  }

}
 