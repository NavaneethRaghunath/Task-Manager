import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { TaskserviceService } from '../taskservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-task',
  templateUrl: './update-task.component.html',
  styleUrls: ['./update-task.component.css']
})
export class UpdateTaskComponent implements OnInit {

  taskid: number;
  task: String;
  parenttask: String;
  startdate: String; 
  enddate: String;
  priority: number;

  constructor(private _shared: SharedService,
              private taskservice: TaskserviceService,
              private router: Router) { }

  // isDisabled: boolean = false;           
  ngOnInit() {
  
    this.taskid = this._shared.taskid;
    this.task = this._shared.task;
    this.parenttask = this._shared.parenttask;
    this.startdate = this._shared.startdate;
    this.enddate = this._shared.enddate;
    this.priority = this._shared.priority;

  }
  
  onSubmit(updtask: any): void{  
       
    this.taskservice.updateTask(updtask.value).subscribe(  
     data => {       
        alert("Task updated");
        this.router.navigate(['/view-task'])
     },  
     error => alert(error));  
  }  

}
