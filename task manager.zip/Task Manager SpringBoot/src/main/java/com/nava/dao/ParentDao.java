package com.nava.dao;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nava.bean.Parent;

@Repository
public interface ParentDao extends CrudRepository<Parent, Integer> {


	@Modifying
    @Query("update Parent m set m.parenttask = :parenttask where m.parentid = :parentid")
    public void updateParentTask(@Param("parentid") int parentid,@Param("parenttask") String parenttask);


    @Query("select parentid from Parent where parenttask = :parenttask")
	public int findparenttask(@Param("parenttask")String parenttask);
	
}
