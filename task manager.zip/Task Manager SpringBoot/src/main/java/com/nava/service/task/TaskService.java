package com.nava.service.task;

import java.util.List;

import com.nava.bean.Parent;
import com.nava.model.Modeltask;
import com.nava.model.Mytask;

public interface TaskService {
	
	public void saveTask(Modeltask task);
	
	public void savePTask(Parent parenttask);
	
	public int findpid(String parenttask);
	
	public List<Mytask> getTasks();
	
	public void updateTask(int taskid, String task,String startdate,String enddate, int priority);
	
	public void updateParentTask(int taskid, String parentTask);
    
	public void updateEnddate(int taskid, String enddate);

}
