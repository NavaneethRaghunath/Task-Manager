package com.nava.service.task;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nava.bean.Parent;
import com.nava.bean.Task;
import com.nava.dao.ParentDao;
import com.nava.dao.TaskDao;
import com.nava.model.Mytask;

@Service
@Transactional

public class TaskServiceImpl {

    @Autowired  
    private TaskDao taskdao;
    
    @Autowired
    private ParentDao parentdao;
    
    public void saveTask(Task task) {
    	taskdao.save(task);
    }
    
    public void saveParentTask(Parent ptask) {
    	
    	parentdao.save(ptask);
    	
    }
    
    public int findpid(String parenttask) {
    	return parentdao.findparenttask(parenttask);
    }
    
    public List<Mytask> getTasks() {
    	
    	return taskdao.findTasks();
    	
    }
    
    public void updateTask(int taskid, String task,String startdate,String enddate, int priority) {  
    	
    	taskdao.mngTask(taskid, task, startdate, enddate,  priority);
    	
    	
    }  
    
	public void updateParentTask(int taskid, String parentTask) {
		
		int parentid = taskdao.findTask(taskid);
		
		parentdao.updateParentTask(parentid, parentTask);
	
	}  
        
    public void updateEnddate(int taskid,String enddate) {  
    
    	taskdao.updateEnddate(taskid,enddate);  

    }


}  
