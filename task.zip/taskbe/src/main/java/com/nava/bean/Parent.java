package com.nava.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
@Entity  
public class Parent {  
	
    @Id  
    @GeneratedValue(strategy=GenerationType.IDENTITY)  
    private int parentid;  
    
    private String parenttask;

	public int getParentid() {
		return parentid;
	}

	public String getParenttask() {
		return parenttask;
	}

	public void setParenttask(String parenttask) {
		this.parenttask = parenttask;
	}

	public void setParentid(int parentid) {
		this.parentid = parentid;
	}

	@Override
	public String toString() {
		return "Parenttask [parentid=" + parentid + ", parenttask=" + parenttask + "]";
	}

	
}	