package com.nava.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nava.bean.Parent;
import com.nava.bean.Project;
import com.nava.bean.Task;
import com.nava.bean.User;
import com.nava.model.Modelproj;
import com.nava.model.Modeltask;
import com.nava.model.Modeluser;
import com.nava.model.Mytask;
import com.nava.service.task.TaskServiceImpl;

@RestController  
@CrossOrigin(origins = "*")

@RequestMapping(value={"/mytask"}) 
public class TaskController {  
      
	@Autowired
    TaskServiceImpl taskservice;
	
	@Autowired
	Parent parent;
	
	@Autowired
	Project project;
	
	@Autowired
	Task mytask;
	
	@Autowired
	User user;
 	
	@PostMapping(value = "/add-task",headers="Accept=application/json", produces = {"application/json"})  
    public ResponseEntity<Modeltask> saveTask(@RequestBody Modeltask task) {  
    		
			Integer projectId = taskservice.findprojectid(task.getProject());
			
			if (projectId == null) {
				
				return new ResponseEntity<Modeltask>(task,HttpStatus.BAD_REQUEST);
			}
			
     		parent.setParentid(0);
     		parent.setParenttask(task.getParenttask());
  
     		taskservice.saveParentTask(parent);
     		
     		int parentId = taskservice.findpid(task.getParenttask());
     		   
     		mytask.setTaskid(0);
     		mytask.setParentid(parentId);
     		mytask.setProjectid(projectId);
     		mytask.setTask(task.getTask());    		
     		mytask.setStartdate(task.getStartdate());
     		mytask.setEnddate(task.getEnddate());
     		mytask.setPriority(task.getPriority());
     		mytask.setCompleted("no");
 
    		taskservice.saveTask(mytask);
    		
    		int taskId = taskservice.findtaskid(task.getTask());
    		System.out.println(taskId);
    		System.out.println(projectId);
    		System.out.println(task.getUser());
    		taskservice.saveUsertask(task.getUser(), taskId, projectId);
    		
    		return new ResponseEntity<Modeltask>(task,HttpStatus.OK);
    
    }
      
	@PostMapping(value = "/add-user",headers="Accept=application/json", produces = {"application/json"})  
    public ResponseEntity<User> saveUser(@RequestBody User user) {  
    		    		   
		user.setProjectid(0);
		user.setTaskid(0);
		user.setUserid(0);
		taskservice.saveUser(user);
		
		return new ResponseEntity<User>(user,HttpStatus.OK);
    
    }
      
	@PostMapping(value = "/add-proj",headers="Accept=application/json", produces = {"application/json"})  
    public ResponseEntity<Project> saveProj(@RequestBody Project p) {  
    		   		   
			project.setProjectid(0);
			project.setProject(p.getProject());
			project.setPriority(p.getPriority());   		
			project.setStartdate(p.getStartdate());
			project.setEnddate(p.getEnddate());
			project.setManager(p.getManager());

    		taskservice.saveProject(project);
    		
    		return new ResponseEntity<Project>(p,HttpStatus.OK);
    
    }
	
	@GetMapping(value = "/gettask", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Mytask> alltasks() {  
    	
          return taskservice.getTasks();  
    
    } 
    
	@GetMapping(value = "/getuser", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Modeluser> allusers() {  
    	
        return taskservice.getUsers();  
  
	} 
    
	@GetMapping(value = "/getproj", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Modelproj> allproj() {  
    	
          return taskservice.getProjects();  
    
    } 
    
	
	@PutMapping(value ="/updatetask", headers="Accept=application/json", produces = MediaType.APPLICATION_JSON_VALUE)  
    public ResponseEntity<Modeltask> updateTask(@RequestBody Modeltask task) {  
        
		taskservice.updateTask(task.getTaskid(),task.getTask(),task.getStartdate(),task.getEnddate(),task.getPriority());
		
		taskservice.updateParentTask(task.getTaskid(),task.getParenttask());
		return new ResponseEntity<Modeltask>(task, HttpStatus.OK);

	}  
    
	@PutMapping(value ="/updateproj", headers="Accept=application/json", produces = MediaType.APPLICATION_JSON_VALUE)  
    public ResponseEntity<Modelproj> updateProj(@RequestBody Modelproj proj) {  
        
		taskservice.updateProj(proj.getProjectid(),proj.getProject(),proj.getStartdate(),proj.getEnddate(),proj.getPriority(),proj.getCompleted());
		
		return new ResponseEntity<Modelproj>(proj, HttpStatus.OK);

	}  
    
	@PutMapping(value ="/updateuser", headers="Accept=application/json", produces = MediaType.APPLICATION_JSON_VALUE)  
    public ResponseEntity<User> updateProj(@RequestBody User user) {  
        
		taskservice.updateUser(user.getEmpid(), user.getFname(), user.getLname());
		
		return new ResponseEntity<User>(user, HttpStatus.OK);

	}  
    	
	
	@PutMapping(value="/update-date", headers="Accept=application/json", produces = MediaType.APPLICATION_JSON_VALUE)  
    public ResponseEntity<Mytask> updateEnddate(@RequestBody Mytask task) {  
		
    	taskservice.updateEnddate(task.getTaskid(),task.getEnddate());  

    	return new ResponseEntity<Mytask>(task, HttpStatus.OK);

    }     
    
    @DeleteMapping(value = "/delete-task/{id}")
    public void deleteTask(@PathVariable int id) {

        taskservice.deleteTask(id);

    }    

    @DeleteMapping(value = "/delete-user/{id}")
    public void deleteUser(@PathVariable int id) {

        taskservice.deleteUser(id);

    }    

    @DeleteMapping(value = "/delete-proj/{id}")
    public void deleteProj(@PathVariable int id) {

        taskservice.deleteProj(id);

    }    

    
}  
