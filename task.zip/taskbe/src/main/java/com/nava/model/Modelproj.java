package com.nava.model;

public class Modelproj {

	private int projectid;
    private String project;
    private String startdate;  
    private String enddate;
    private int nooftasks;
    private String completed;
    private int priority;
	
    
    public int getProjectid() {
		return projectid;
	}
	public void setProjectid(int projectid) {
		this.projectid = projectid;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public int getNooftasks() {
		return nooftasks;
	}
	public void setNooftasks(int nooftasks) {
		this.nooftasks = nooftasks;
	}
	public String getCompleted() {
		return completed;
	}
	public void setCompleted(String completed) {
		this.completed = completed;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	
	@Override
	public String toString() {
		return "Modelproj [projectid=" + projectid + ", project=" + project + ", startdate=" + startdate + ", enddate="
				+ enddate + ", nooftasks=" + nooftasks + ", completed=" + completed + ", priority=" + priority + "]";
	}
	

	
    
    
    
}
