package com.nava.model;

public class Modeltask {

    private int taskid;  
    private int parentid;
    private String project;
    private String task; 
    private int priority;
    private String parenttask;
    private String startdate;  
    private String enddate;
    private int user;
	
    public int getTaskid() {
		return taskid;
	}
	public void setTaskid(int taskid) {
		this.taskid = taskid;
	}
	public int getParentid() {
		return parentid;
	}
	public void setParentid(int parentid) {
		this.parentid = parentid;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public String getParenttask() {
		return parenttask;
	}
	public void setParenttask(String parenttask) {
		this.parenttask = parenttask;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public int getUser() {
		return user;
	}
	public void setUser(int user) {
		this.user = user;
	}
	
	@Override
	public String toString() {
		return "Modeltask [taskid=" + taskid + ", parentid=" + parentid + ", project=" + project + ", task=" + task
				+ ", priority=" + priority + ", parenttask=" + parenttask + ", startdate=" + startdate + ", enddate="
				+ enddate + ", user=" + user + "]";
	}
    
    
}
