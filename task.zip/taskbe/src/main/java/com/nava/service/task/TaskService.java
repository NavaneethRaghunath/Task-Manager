package com.nava.service.task;

import java.util.List;

import com.nava.bean.Parent;
import com.nava.bean.Project;
import com.nava.bean.User;
import com.nava.model.Modelproj;
import com.nava.model.Modeltask;
import com.nava.model.Modeluser;
import com.nava.model.Mytask;

public interface TaskService {
	
	public void saveTask(Modeltask task);
	
	public void savePTask(Parent parenttask);
	
	public void saveProject(Project proj);
	
	public void saveUser(User user);
	
	public void saveUsertask(int empid, int taskid, int projectid);
	
	public int findpid(String parenttask);
	
	public int findprojectid(String project);
	
	public int findtaskid(String task);
	
	public List<Mytask> getTasks();
	
	public List<Modeluser> getUsers();
	
	public List<Modelproj> getProjects();
		
	public void updateTask(int taskid, String task,String startdate,String enddate, int priority);
	
	public void updateParentTask(int taskid, String parentTask);
    
	public void updateEnddate(int taskid, String enddate);
	
    public void updateProj(int projectid, String project, String startdate, String enddate, int priority, String completed);

    public void updateUser(int empid, String fname, String lname);

	public void deleteTask(int id);
	
	public void deleteUser(int id);

	public void deleteProj(int id);


}
