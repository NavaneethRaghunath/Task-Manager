package com.nava.service.task;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nava.bean.Parent;
import com.nava.bean.Project;
import com.nava.bean.Task;
import com.nava.bean.User;
import com.nava.dao.ParentDao;
import com.nava.dao.ProjectDao;
import com.nava.dao.TaskDao;
import com.nava.dao.UserDao;
import com.nava.model.Modelproj;
import com.nava.model.Modeluser;
import com.nava.model.Mytask;

@Service
@Transactional

public class TaskServiceImpl {

    @Autowired  
    private TaskDao taskdao;
    
    @Autowired
    private ParentDao parentdao;
    
    @Autowired
    private ProjectDao projectdao;
    
    @Autowired
    private UserDao userdao;
    
    
    public void saveTask(Task task) {
    	taskdao.save(task);
    }
    
    public void saveParentTask(Parent ptask) {
    	
    	parentdao.save(ptask);
    	
    }
    
    public void saveProject(Project proj) {
    	
    	projectdao.save(proj);
    	
    }
    
    public void saveUser(User user) {
    	
    	userdao.save(user);
    	
    }
    
    public int findpid(String parenttask) {
    	return parentdao.findparenttask(parenttask);
    }
    
    public Integer findprojectid(String project) {
    	
    	return projectdao.findproject(project);

    }
    
    public int findtaskid(String task) {
    	return taskdao.findutask(task);
    }

    public void saveUsertask(int empid, int taskid, int projectid) {
    
   // 	User user = userdao.finduser(empid);
    	
//    	user.setTaskid(taskid);
//    	user.setProjectid(projid);
//    	user.setUserid(0);
    	
    	userdao.updateUserTask(empid,taskid,projectid);
    }
    
    public List<Mytask> getTasks() {
    	
    	return taskdao.findTasks();
    	
    }
    
    public List<Modeluser> getUsers() {
    	
    	return userdao.findUsers();
    	
    }
    
    public List<Modelproj> getProjects(){
		
		List<Modelproj> projects = new ArrayList<Modelproj>();
		
		Iterable<Project> result = projectdao.findAll();

		for (Project p : result) {
			Modelproj project = new Modelproj();
			int taskcount = taskdao.findTaskCount(p.getProjectid());
			int status = taskdao.findChkStatus(p.getProjectid());
			
			project.setProjectid(p.getProjectid());
			project.setProject(p.getProject());
			project.setPriority(p.getPriority());
			project.setStartdate(p.getStartdate());
			project.setEnddate(p.getEnddate());
			project.setNooftasks(taskcount);
			
			if (status > 0) {
				project.setCompleted("no");
			}else {
				project.setCompleted("yes");
			}
			
			projects.add(project);
		}
		
		return projects;
	}
//
//	public List<Modeluser> getUsers(){
//		
////		User user = null;
////		List<User> users = null;
////		
////		Iterable<User> result = userdao.findAll();
////		
////		for (User u : result) {
////			
////			user.setFname(u.getFname());
////			user.setLname(u.getLname());
////			user.setEmpid(u.getEmpid());
////			
////			users.add(user);
////		}
////		
////		return users;
////		
//
//    	return userdao.findUsers();
//
//	}
	
    public void updateTask(int taskid, String task,String startdate,String enddate, int priority) {  
    	
    	taskdao.mngTask(taskid, task, startdate, enddate,  priority);
    	
    }  
    
	public void updateParentTask(int taskid, String parentTask) {
		
		int parentid = taskdao.findTask(taskid);
		
		parentdao.updateParentTask(parentid, parentTask);
	
	}  
        
    public void updateEnddate(int taskid,String enddate) {  
    
    	taskdao.updateEnddate(taskid,enddate);  

    }
    
    public void updateProj(int projectid, String project, String startdate, String enddate, int priority, 
    		String completed) {
    	
    	Optional<Project> p = projectdao.findById(projectid);
    	
    	if (p.get().getProject() == project) {
    		
    	}else {
    		projectdao.updateProject(projectid, project, startdate, enddate, priority);
    	}
    	
    	taskdao.updateStatus(projectid, completed);
    }

    public void updateUser(int empid, String fname, String lname) {
    	
    	userdao.updateUser(empid, fname, lname);
    	
    }
    
    public void deleteTask(int id) {
    	
    	taskdao.deleteById(id);
    	userdao.deleteTask(id);
    	
    }
    
    public void deleteUser(int id) {
    	
    	userdao.deleteById(id);
    	
    }
    
    public void deleteProj(int id) {
    	
    	projectdao.deleteById(id);
    	taskdao.deleteTask(id);
    	userdao.deleteProj(id);
    	
    }

}