export class Modelproj {  
  
    projectid: number;
    project: String;
    startdate: String; 
    enddate: String;
    priority: number;

}  