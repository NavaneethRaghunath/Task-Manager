export class Modeltask {  
  
    taskid: number;
    parentid: number;
    task: String;
    parenttask: String;
    startdate: String; 
    enddate: String;
    priority: number;

}  