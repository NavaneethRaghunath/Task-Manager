export class Modeluser {  
  
    empid: number;
    fname: String;
    lname: String;
    
}  