import {Component, OnInit, ViewChild} from '@angular/core';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { TaskserviceService } from '../taskservice.service';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {
  addUserForm: FormGroup;
  displayuser = null;
  displayedColumns: string[] = ['empid','fname','lname','actions'];
  dataSource = new MatTableDataSource(this.displayuser);

  @ViewChild(MatSort) sort: MatSort;

  constructor(private taskservice: TaskserviceService, 
              private router: Router,
              private _shared: SharedService) { 

      taskservice.getUser().subscribe(data =>{
        this.displayuser = data;
        this.dataSource.data = this.displayuser;                 
        this.dataSource.sort = this.sort; 
      });

    }

  ngOnInit() {
    
    this.addUserForm = new FormGroup({
      fname: new FormControl(),
      lname: new FormControl(),
      empid: new FormControl()
    
    });  
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  onSubmit(): void{

      this.taskservice.createUser(this.addUserForm.value).subscribe(data =>{
              alert("User added!");
              this.router.navigate(['/view-task']);
             },
        error =>{alert(error);
       })
  
    }

    updateUser(upduser : any): void{
    
      this._shared.empid      = upduser.empid;
      this._shared.fname      = upduser.fname;
      this._shared.lname      = upduser.lname;
      
      this.router.navigate(['/update-user']);
    }
 
  deleteUser(dlttask: any): void{

    this.taskservice.deleteUser(dlttask.empid).subscribe(data =>{  
      alert("User deleted");
      this.router.navigate(['/view-task']);
    },  
      error => alert(error)); 
  }

}