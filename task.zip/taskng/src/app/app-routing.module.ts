import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewTaskComponent } from './view-task/view-task.component';
import { AddTaskComponent } from './add-task/add-task.component';
import { UpdateTaskComponent } from './update-task/update-task.component';
import { AddprojectComponent } from './addproject/addproject.component';
import { AdduserComponent } from './adduser/adduser.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { UpdateProjComponent } from './update-proj/update-proj.component';

const routes: Routes = [  
  { path: '', redirectTo: 'view-task', pathMatch: 'full' },  
  { path: 'view-task', component: ViewTaskComponent },  
  { path: 'add-project', component: AddprojectComponent },  
  { path: 'add-user', component: AdduserComponent },  
  { path: 'add-task', component: AddTaskComponent },  
  { path: 'update-task', component: UpdateTaskComponent},
  { path: 'update-user', component: UpdateUserComponent},
  { path: 'update-proj', component: UpdateProjComponent},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
