import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  constructor() { }

  taskid: number;
  projectid: number;
  task: String;
  parenttask: String;
  startdate: String; 
  enddate: String;
  priority: number;
  empid: number;
  fname: String;
  lname: String;
  nooftasks: number;
  completed: String;
  project: String;
  
}
