import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { TaskserviceService } from '../taskservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-proj',
  templateUrl: './update-proj.component.html',
  styleUrls: ['./update-proj.component.css']
})
export class UpdateProjComponent implements OnInit {

  
  projectid: number;
  project: String;
  startdate: String; 
  enddate: String;
  priority: number;
  nooftasks: number;
  completed: String;

  constructor(private _shared: SharedService,
              private taskservice: TaskserviceService,
              private router: Router) { }

  ngOnInit() {

    this.projectid = this._shared.projectid;
    this.project = this._shared.project;
    this.completed = this._shared.completed;
    this.startdate = this._shared.startdate;
    this.enddate = this._shared.enddate;
    this.priority = this._shared.priority;

  }

  onSubmit(updproj: any): void{  
       console.log(updproj.value);
    this.taskservice.updateProj(updproj.value).subscribe(  
     data => {       
        alert("Project updated");
        this.router.navigate(['/add-task'])
     },  
     error => alert(error));  
  }  

}
