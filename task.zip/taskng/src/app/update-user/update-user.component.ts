import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { TaskserviceService } from '../taskservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {

  empid: number;
  fname: String;
  lname: String;

  constructor(private _shared: SharedService,
              private taskservice: TaskserviceService,
              private router: Router) { }

  ngOnInit() {
  
    this.empid = this._shared.empid;
    this.fname = this._shared.fname;
    this.lname = this._shared.lname;

  }
  
  onSubmit(upduser: any): void{  
     console.log(upduser.value);  
    this.taskservice.updateUser(upduser.value).subscribe(  
     data => {       
        alert("User updated");
        this.router.navigate(['/add-project'])
     },  
     error => alert(error));  
  }  

}
