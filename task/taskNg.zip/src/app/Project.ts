export class Project {  
  
    projectid: number;
    project: String;
    manager: String;
    startdate: String; 
    enddate: String;
    priority: number;

}  