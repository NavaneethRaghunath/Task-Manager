import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { TaskserviceService } from '../taskservice.service';
import { SharedService } from '../shared.service';
import {MatTableDataSource} from '@angular/material/table';
import {MatSort} from '@angular/material/sort';
import { FormGroup, FormControl } from '@angular/forms';


@Component({
  selector: 'app-addproject',
  templateUrl: './addproject.component.html',
  styleUrls: ['./addproject.component.css']
})
export class AddprojectComponent implements OnInit {

  displaytask = null;
  addProjForm: FormGroup;
  displayedColumns: string[] = ['projectid','project','nooftasks','completed','priority','startdate','enddate','actions'];
  dataSource = new MatTableDataSource(this.displaytask);
  @ViewChild(MatSort) sort: MatSort;

  constructor(private taskservice: TaskserviceService, 
    private router: Router,
    private _shared: SharedService) { 

    taskservice.getProj().subscribe(data =>{
          this.displaytask = data;
          this.dataSource.data = this.displaytask;                 
          this.dataSource.sort = this.sort;
        });
  }

  ngOnInit() {
    this.addProjForm = new FormGroup({
      project: new FormControl(),
      startdate: new FormControl(),
      enddate: new FormControl(),
      priority: new FormControl(),
      manager: new FormControl()
    });    
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  addProj(): void{
      console.log(this.addProjForm.value);
      this.taskservice.createProj(this.addProjForm.value).subscribe(data =>{
              alert("Project added!");
              this.router.navigate(['/add-project']);
             },
        error =>{alert(error);
       })
  
    }

  updateProj(proj : any): void{
    
      this._shared.projectid  = proj.projectid;
      this._shared.project    = proj.project;
      this._shared.nooftasks  = proj.nooftasks;
      this._shared.completed  = proj.completed;
      this._shared.startdate  = proj.startdate;
      this._shared.enddate    = proj.enddate;
      this._shared.priority   = proj.priority;
      
      this.router.navigate(['/update-proj']);
    }

  deleteProj(proj: any): void{

    this._shared.projectid = proj.projectid;

    this.taskservice.deleteProj(this._shared).subscribe(data =>{  
      alert("Project deleted");
      this.router.navigate(['/add-project'])
    },  
      error => alert(error)); 
  }

}