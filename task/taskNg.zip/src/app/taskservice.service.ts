import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';  
import { Observable } from 'rxjs';  
import { Modeltask } from './Modeltask';
import { DatePipe } from '@angular/common';
import { Modeluser } from './Modeluser';
import { Modelproj } from './Modelproj';
import { Project } from './Project';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class TaskserviceService {

  private baseUrl = 'http://localhost:8080/mytask/';  

  currentDate: Date;

  constructor(private http:HttpClient,
              private datePipe: DatePipe) { }

  createTask(task: Modeltask): Observable<any> {
    task.startdate = this.datePipe.transform(task.startdate, 'dd/MM/yyyy');
    task.enddate = this.datePipe.transform(task.enddate, 'dd/MM/yyyy');
    console.log(task);
    return this.http.post(`${this.baseUrl}`+'add-task', task, httpOptions);  
  }

  createUser(user: Modeluser): Observable<any> {

    console.log(user);
    return this.http.post(`${this.baseUrl}`+'add-user', user, httpOptions);  

  }

  createProj(proj: Modelproj): Observable<any> {
    proj.startdate = this.datePipe.transform(proj.startdate, 'dd/MM/yyyy');
    proj.enddate = this.datePipe.transform(proj.enddate, 'dd/MM/yyyy');
    console.log(proj);
    return this.http.post(`${this.baseUrl}`+'add-proj', proj, httpOptions);  

  }

  // getmytask() {
  //   return [
  //     {taskid: 1, task: 'Hydrogen', parenttask: 'Nitrogen', startdate: '12/1/2109', enddate: '12/1/2009', priority: 2},
  //     {taskid: 2, task: 'nava', parenttask: 'oxy', startdate: '12/1/21', enddate: '12/1/20', priority: 2}
  //   ];
 
  // }

  getTask(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'gettask');  
  }

  getUser(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'getuser');  
  }

  getProj(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'getproj');  
  }
  
  updateTask(task: Modeltask): Observable<any>{
    return this.http.put(`${this.baseUrl}`+'updatetask', task, httpOptions);  
  }

  updateUser(user: Modeluser): Observable<any>{
    return this.http.put(`${this.baseUrl}`+'updateuser', user, httpOptions);  
  }

  updateProj(proj: Project): Observable<any>{
    return this.http.put(`${this.baseUrl}`+'updateproj', proj, httpOptions);  
  }

  putTaskDate(task: any): Observable<any>{
    this.currentDate = new Date();
    task.enddate = this.datePipe.transform(this.currentDate, 'dd/MM/yyyy');
    console.log(task);
    return this.http.put(`${this.baseUrl}`+'update-date', task, httpOptions);  
  }

  deleteTask(task: any): Observable<any>{        
    return this.http.delete(`${this.baseUrl}`+'delete-task/' + task.taskid);  
  }

  deleteUser(user: any): Observable<any>{        
    return this.http.delete(`${this.baseUrl}`+'delete-user/' + user.empid);  
  }

  deleteProj(proj: any): Observable<any>{        
    return this.http.delete(`${this.baseUrl}`+'delete-proj/' + proj.projectid);  
  }

}
 