import { Component, OnInit, ViewChild } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import { TaskserviceService } from '../taskservice.service';
import { Router } from '@angular/router';
import { SharedService } from '../shared.service';
import { MatSort } from '@angular/material';


@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.css']
})
export class ViewTaskComponent implements OnInit {
 
  displaytask = null;
  displayedColumns: string[] = ['taskid','task','parenttask','priority','startdate','enddate','actions'];
  dataSource = new MatTableDataSource(this.displaytask);
  @ViewChild(MatSort) sort: MatSort;

  constructor(private taskservice: TaskserviceService, 
              private router: Router,
              private _shared: SharedService) { 
            }

  ngOnInit() {
             this.taskservice.getTask().subscribe(data =>{
                 this.displaytask = data;
                 this.dataSource.data = this.displaytask;                 
         });
        this.dataSource.sort = this.sort;
  }

 // displaytask =this.taskservice.getmytask();

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  editTask(updtask : any): void{
    
    this._shared.taskid      = updtask.taskid;
    this._shared.task        = updtask.task;
    this._shared.parenttask  = updtask.parenttask;
    this._shared.startdate   = updtask.startdate;
    this._shared.enddate     = updtask.enddate;
    this._shared.priority    = updtask.priority;
    
    this.router.navigate(['/update-task']);
  }  

 
  endtask(upddate : any): void{
    
    this._shared.taskid = upddate.taskid;
    this._shared.enddate = upddate.enddate;
 
    this.taskservice.putTaskDate(this._shared).subscribe(data =>{  
          alert("End date updated");
          this.router.navigate(['/view-task'])
    },  
          error => alert(error)); 
  }

  deletetask(dlttask: any): void{

    this._shared.taskid = dlttask.taskid;

    this.taskservice.deleteTask(this._shared).subscribe(data =>{  
      alert("Task deleted");
      this.router.navigate(['/view-task'])
    },  
      error => alert(error)); 
  }

}