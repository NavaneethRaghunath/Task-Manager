package com.nava.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
@Entity
public class Project {

    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int projectid;  
    
    private String project;
    private String startdate;  
    private String enddate;
    private int priority;
    private String manager;
    
	public int getProjectid() {
		return projectid;
	}
	public void setProjectid(int projectid) {
		this.projectid = projectid;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}	
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	
	@Override
	public String toString() {
		return "Project [projectid=" + projectid + ", project=" + project + ", startdate=" + startdate + ", enddate="
				+ enddate + ", priority=" + priority + ", manager=" + manager + "]";
	}

	
}
