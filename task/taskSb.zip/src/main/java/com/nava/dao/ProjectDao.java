package com.nava.dao;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nava.bean.Project;

@Repository
public interface ProjectDao extends CrudRepository<Project, Integer> {

	
	   @Query("select m.projectid from Project m where m.project = :project")
		public Integer findproject(@Param("project") String project);
	   
		@Modifying
	    @Query("update Project m set m.project = :project, m.startdate = :startdate, m.enddate = :enddate, m.priority = :priority where m.projectid = :projectid")
	    public void updateProject(@Param("projectid") int projectid,@Param("project") String project,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("priority") int priority );

}
