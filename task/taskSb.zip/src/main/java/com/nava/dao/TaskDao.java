package com.nava.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nava.bean.Task;
import com.nava.model.Mytask;

@Repository
public interface TaskDao extends JpaRepository<Task, Integer> {

	@Query("select parentid from Task where taskid = :taskid")
	public int findTask(@Param("taskid")int taskid);
	
	@Query("select taskid from Task where task = :task")
	public int findutask(@Param("task")String task);
		
	@Query("select new com.nava.model.Mytask(t.taskid, t.task, p.parenttask, t.startdate, t.enddate, t.priority) from Task t, Parent p where t.parentid = p.parentid")
	public List <Mytask> findTasks(); 
	
	@Query("select count(*) from Task where projectid = :projectid")
	public int findTaskCount(@Param("projectid") int projectid);
	
	@Query("select count(*) from Task where projectid = :projectid and completed = 'no'")
	public int findChkStatus(@Param("projectid") int projectid);
	
	@Modifying
	@Query("update Task m set m.task = :task,m.startdate = :startdate,m.enddate = :enddate,m.priority = :priority where m.taskid = :taskid")
	public void mngTask(@Param("taskid")int taskid,@Param("task") String task,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("priority") int priority);

	@Modifying
    @Query("update Task m set m.enddate = :enddate where m.taskid = :taskid")
    public void updateEnddate(@Param("taskid")int taskid,@Param("enddate") String enddate); 

	@Modifying
    @Query("update Task m set m.completed = :completed where m.projectid = :projectid")
    public void updateStatus(@Param("projectid")int projectid,@Param("completed") String completed); 
	
	@Modifying
	@Query("delete from Task m where m.projectid = :projectid")
	public void deleteTask(@Param("projectid")int projectid);

}
