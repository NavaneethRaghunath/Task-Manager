package com.nava.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nava.bean.User;
import com.nava.model.Modeluser;

@Repository
public interface UserDao extends CrudRepository<User, Integer> {

//	@Query("select u from User u where u.empid = :empid")
//	public User finduser(@Param("empid") int empid);
	
	@Modifying
	@Query("update User u set u.taskid = :taskid, u.projectid = :projectid where u.empid = :empid")
	public void updateUserTask(@Param("empid") int empid, @Param("taskid") int taskid, @Param("projectid") int projectid);
	
	@Query("select new com.nava.model.Modeluser(u.fname, u.lname, u.empid) from User u")
	public List<Modeluser> findUsers(); 	
	
	@Modifying
    @Query("update User u set u.fname = :fname, u.lname = :lname where u.empid = :empid")
    public void updateUser(@Param("empid")int empid,@Param("fname") String fname,@Param("lname") String lname);

	@Modifying
	@Query("delete from User u where u.taskid = :taskid")
	public void deleteTask(@Param("taskid")int taskid);
	
	@Modifying
	@Query("delete from User u where u.projectid = :projectid")
	public void deleteProj(@Param("projectid")int projectid);
	
}
